# Junior Data modelling and storage - Module 2: Guided validation

Module ID: MOD-DE-J-MODEL-02. Content version: 1.2. Review: NEEDS_EXPERT_REVIEW.

## Learn

Read [the local lesson: Modelling data before optimizing it](../topics/DE-MODEL.md). It includes a conceptual explanation, worked example and a self-check with an answer. Then use the linked official resources for additional detail.

## Skill focus

- **MS-DE13: Optimise warehouse workloads** — Compare access speed and loading cost before selecting a warehouse optimisation.
- **MS-DE16: Trace data dependencies** — Identify downstream consumers affected by a dataset change.

## Study and practice sequence

1. Read the linked local explanation and work through its example.
2. Answer the self-check before looking at the answer.
3. Inspect the official learning resources below for the techniques used in this module.
4. Complete the assigned tasks below and record checks and evidence.

## Learning prerequisites

- Before MS-DE13, demonstrate MS-DE03: Establish a working warehouse before measuring changes to its workloads.

Prerequisites taught within this module are studied first. Cross-module prerequisites are scheduled by the pathway engine. These are pending local learning-order decisions, not claims of universal occupational dependency.

## Assigned tasks and submission evidence


In Data modelling and storage, demonstrate the following junior tasks:

- MS-DE13: Measure a supplied warehouse query before and after one guided optimisation; confirm unchanged results.
- MS-DE16: Identify downstream consumers of a supplied dataset change using existing lineage information.

Submit evidence:

- MS-DE13: Workload definition, before/after measurements, result reconciliation and decision record.
- MS-DE16: Dependency map, affected-consumer list, assumptions and change verification results.

## Official learning resources

- [PostgreSQL tutorial](https://www.postgresql.org/docs/current/tutorial.html)

## Assessment boundary

Completion is not an attainment decision. An approved external assessment task/rubric, skill-specific evidence at the selected Level and approved catalog dependencies are required for official assessment. Completion does not automatically pass all taught skills. This lesson has not yet received that approval.
