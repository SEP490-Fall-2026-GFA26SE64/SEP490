# Senior Test design and planning - Module 2: Complex validation and improvement

Module ID: MOD-QA-S-DESIGN-02. Content version: 1.2. Review: NEEDS_EXPERT_REVIEW.

## Learn

Read [the local lesson: Selecting informative test cases](../topics/QA-DESIGN.md). It includes a conceptual explanation, worked example and a self-check with an answer. Then use the linked official resources for additional detail.

## Skill focus

- **MS-QA09: Apply equivalence partitioning** — Select representative cases from distinct valid and invalid input classes.
- **MS-QA10: Apply boundary value analysis** — Test values at and around the boundaries of ordered input classes.
- **MS-QA11: Prioritise tests by risk** — Order tests using failure likelihood and product impact.

## Study and practice sequence

1. Read the linked local explanation and work through its example.
2. Answer the self-check before looking at the answer.
3. Inspect the official learning resources below for the techniques used in this module.
4. Complete the assigned tasks below and record checks and evidence.

## Learning prerequisites

- Before MS-QA10, demonstrate MS-QA09: Identify ordered input partitions before testing their boundaries.

Prerequisites taught within this module are studied first. Cross-module prerequisites are scheduled by the pathway engine. These are pending local learning-order decisions, not claims of universal occupational dependency.

## Assigned tasks and submission evidence


In Test design and planning, demonstrate the following senior tasks:

- MS-QA09: Review interacting partitions across complex rules; identify missing classes and justify reduced test combinations.
- MS-QA10: Review boundaries across interacting rules and state transitions; prioritise off-by-one and limit-related risks.
- MS-QA11: Review risk priorities under release constraints; justify changes and communicate untested residual risks.

Submit evidence:

- MS-QA09: Partition model, selected cases, expected results and coverage rationale.
- MS-QA10: Boundary table, test cases, expected/actual results and rationale.
- MS-QA11: Risk register, prioritised tests, evidence sources and residual-risk statement.

## Official learning resources

- [ISTQB CTFL 4.0.1 syllabus](https://istqb.org/?download_id=3345&sdm_process_download=1)

## Assessment boundary

Completion is not an attainment decision. An approved external assessment task/rubric, skill-specific evidence at the selected Level and approved catalog dependencies are required for official assessment. Completion does not automatically pass all taught skills. This lesson has not yet received that approval.
