# Automate infrastructure procedures

Module ID: MOD-MS-INF03. Catalog: 0.8.0. Content version: 2.0. Review: NEEDS_EXPERT_REVIEW.

Primary and only teaching skill: **MS-INF03 — Automate infrastructure procedures**.

Implement and verify scripts for repeatable infrastructure tasks.

## Study material

This module consolidates existing source-linked material for this skill. Read only the sections relevant to this skill; integrated examples may mention supporting skills without claiming to teach or assess them. Content depth and role suitability still require expert review.

- [Coding and scripting](https://understand-digital-data-roles-skills.service.gov.uk/role/infrastructure-engineer/)

## Focused practice

Choose the practice appropriate to the selected Level. These are retained local proposals, not official framework scoring standards.

Use the linked reference to implement a bounded example demonstrating the skill definition; record the result and checks. The role-specific lab must be authored and reviewed before official use.

## Readiness and assessment


Assessment tasks, rubric/version selection and evidence rules belong to the assessment service/documentation, not to this ontology. Completing this module alone does not establish skill attainment at every Level. Missing evidence is NOT_ASSESSED, not a score of zero.

## Source trace

- [Earlier teaching material: MOD-READ-INF03](../../../sources/ontology_v07_history/modules/MOD-READ-INF03.md)
