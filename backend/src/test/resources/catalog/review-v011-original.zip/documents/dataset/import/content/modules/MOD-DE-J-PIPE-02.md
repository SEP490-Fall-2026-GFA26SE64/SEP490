# Junior Data pipeline implementation and integration - Module 2: Guided validation

Module ID: MOD-DE-J-PIPE-02. Content version: 1.2. Review: NEEDS_EXPERT_REVIEW.

## Learn

Read [the local lesson: Treating a pipeline as a sequence of contracts](../topics/DE-PIPE.md). It includes a conceptual explanation, worked example and a self-check with an answer. Then use the linked official resources for additional detail.

## Skill focus

- **MS-DE10: Implement data extraction** — Extract source records into a controlled staging area.
- **MS-DE11: Implement transformation rules** — Convert values and enforce business rules during data processing.
- **MS-DE12: Orchestrate retry-safe pipeline tasks** — Order dependent tasks and make retries preserve correct outputs.

## Study and practice sequence

1. Read the linked local explanation and work through its example.
2. Answer the self-check before looking at the answer.
3. Inspect the official learning resources below for the techniques used in this module.
4. Complete the assigned tasks below and record checks and evidence.

## Assigned tasks and submission evidence


In Data pipeline implementation and integration, demonstrate the following junior tasks:

- MS-DE10: Extract a supplied source into staging and reconcile record counts with guidance.
- MS-DE11: Implement supplied transformation rules and check outputs against worked examples.
- MS-DE12: Run a provided task sequence; demonstrate a safe retry using a supplied failure case.

Submit evidence:

- MS-DE10: Extraction code, checkpoints, reconciliation and recovery test logs.
- MS-DE11: Rule specification, transformation code, edge-case fixtures and test results.
- MS-DE12: Dependency graph, orchestration configuration and repeated-run/failure test results.

## Official learning resources

- [Airflow workflow tutorial](https://airflow.apache.org/docs/apache-airflow/stable/tutorial/fundamentals.html)

## Assessment boundary

Completion is not an attainment decision. An approved external assessment task/rubric, skill-specific evidence at the selected Level and approved catalog dependencies are required for official assessment. Completion does not automatically pass all taught skills. This lesson has not yet received that approval.
