# report test findings — Independent implementation

Module ID: MOD-FOCUS-QA04-MEDIUM. Content version: 1.0. Review: NEEDS_EXPERT_REVIEW.

## Purpose and scenario

Practice **report test findings** using a sandbox checkout service with documented acceptance criteria and known defects. This locally authored review package is a scaffold for expert lesson/lab authoring, not a complete approved course.

## Teaching focus and difficulty

| Skill | Teaching focus | Difficulty | Meaning |
|---|---|---|---|
| MS-QA04 — report test findings | PRIMARY | MEDIUM | Main instructional objective, with direct practice and evidence. |
| MS-QA03 — execute software tests | SUPPORTING | LOW | Supporting activity, not an equivalent primary treatment. |
| MS-CORE02 — Manage source changes with version control | INCIDENTAL | LOW | Context only; no teaching or mastery credit. |

## Read and prepare

Read [the retained source-linked introduction](MOD-QA-J-EXEC-01.md) for terminology and references. It is a reference, not a compulsory module completion. Review the supplied scenario, inputs and expected outputs with the instructor. For real use, experts must provide and approve the actual sandbox assets, worked examples and task/rubric configuration.

## Primary task

Communicate test results and defects independently with reproducible evidence and impact.

Implement a variant independently from the stated requirements. Diagnose one injected failure and justify the correction with before/after checks.

## Supporting task

Execute supplied tests and record expected and observed results with guidance. The supporting activity develops execute software tests; review its evidence separately from the primary result.

## Incidental context

A repository snapshot is provided as context; source-control operations are not taught or assessed here. Merely using that context does not close a gap for MS-CORE02.

## Checks and evidence

Submit the primary artifact, stated assumptions, expected-versus-observed checks and one limitation. Include evidence for the supporting activity. For HIGH difficulty, add the alternative comparison, failure analysis and recovery checks; for MEDIUM, include diagnosis and correction; for LOW, retain the worked-example checklist and changed-input result. No evidence or attainment decision is claimed for incidental context.

## Readiness and assessment boundary

Skill prerequisite edges determine readiness; supporting/incidental links do not create new prerequisites. An approved external task/rubric and compatible learner evidence are required to confirm readiness or attainment. Difficulty is an expert authoring category, not a numeric score threshold, role-Level shortcut, or expected mastery increase. Completion never automatically passes any skill.
