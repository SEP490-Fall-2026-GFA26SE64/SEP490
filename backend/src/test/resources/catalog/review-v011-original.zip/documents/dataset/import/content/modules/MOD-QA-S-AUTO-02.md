# Senior Test automation and integration - Module 2: Complex validation and improvement

Module ID: MOD-QA-S-AUTO-02. Content version: 1.2. Review: NEEDS_EXPERT_REVIEW.

## Learn

Read [the local lesson: Making automated checks reliable](../topics/QA-AUTO.md). It includes a conceptual explanation, worked example and a self-check with an answer. Then use the linked official resources for additional detail.

## Skill focus

- **MS-QA15: Execute performance tests** — Measure response behaviour under a defined workload and environment.
- **MS-QA16: Investigate flaky automated tests** — Use retry results and controlled reruns to diagnose inconsistent test outcomes.

## Study and practice sequence

1. Read the linked local explanation and work through its example.
2. Answer the self-check before looking at the answer.
3. Inspect the official learning resources below for the techniques used in this module.
4. Complete the assigned tasks below and record checks and evidence.

## Learning prerequisites

- Before MS-QA16, demonstrate MS-QA06: Understand automated setup and assertions before diagnosing flaky outcomes.

Prerequisites taught within this module are studied first. Cross-module prerequisites are scheduled by the pathway engine. These are pending local learning-order decisions, not claims of universal occupational dependency.

## Assigned tasks and submission evidence


In Test automation and integration, demonstrate the following senior tasks:

- MS-QA15: Review performance coverage and bottlenecks; compare workload assumptions and justify conclusions and limits.
- MS-QA16: Review flakiness across a suite; prioritise causes and verify that reliability improvements preserve fault detection.

Submit evidence:

- MS-QA15: Workload specification, environment details, measurements and interpretation.
- MS-QA16: Rerun logs, controlled experiments, cause analysis and post-fix results.

## Official learning resources

- [Playwright writing tests](https://playwright.dev/docs/writing-tests)
- [Playwright retries](https://playwright.dev/docs/test-retries)

## Assessment boundary

Completion is not an attainment decision. An approved external assessment task/rubric, skill-specific evidence at the selected Level and approved catalog dependencies are required for official assessment. Completion does not automatically pass all taught skills. This lesson has not yet received that approval.
