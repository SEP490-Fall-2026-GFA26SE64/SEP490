# Middle Data quality and operations - Module 1: Independent implementation

Module ID: MOD-DE-M-QUAL-01. Content version: 1.1. Review: NEEDS_EXPERT_REVIEW.

## Learn

Read [the local lesson: Using explicit data quality rules](../topics/DE-QUAL.md). It includes a conceptual explanation, worked example and a self-check with an answer. Then use the linked official resources for additional detail.

## Skill focus

- **MS-DE05: Verify data quality** — Check records against explicit completeness, accuracy and consistency rules.
- **MS-DE06: Maintain metadata documentation** — Record dataset meaning, ownership and structural metadata.
- **MS-DE07: Monitor pipeline operations** — Observe pipeline runs and investigate operational failures.

## Study and practice sequence

1. Read the linked local explanation and work through its example.
2. Answer the self-check before looking at the answer.
3. Inspect the official learning resources below for the techniques used in this module.
4. Complete the assigned tasks below and record checks and evidence.

## Assigned tasks and submission evidence


In Data quality and operations, demonstrate the following middle tasks:

- MS-DE05: Define dataset-specific quality checks, investigate failures and verify corrections independently.
- MS-DE06: Maintain metadata through schema changes; verify definitions with owners and dependent consumers.
- MS-DE07: Diagnose routine production failures; restore execution safely and validate the resulting data independently.

Submit evidence:

- MS-DE05: Quality rules, failing records, investigation notes and rerun results.
- MS-DE06: Data dictionary, ownership records, change history and review findings.
- MS-DE07: Run logs, alert examples, incident timeline and recovery verification.

## Official learning resources

- [PostgreSQL tutorial](https://www.postgresql.org/docs/current/tutorial.html)
- [pytest getting started](https://docs.pytest.org/en/stable/getting-started.html)

## Assessment boundary

Completion is not an attainment decision. Rubric 1.2, level-specific evidence and approved catalog dependencies are required for official assessment. This lesson has not yet received that approval.
