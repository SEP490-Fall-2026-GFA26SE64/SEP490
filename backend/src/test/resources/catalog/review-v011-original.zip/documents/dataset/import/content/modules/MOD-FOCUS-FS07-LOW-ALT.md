# perform software unit testing — Guided practice — Focused verification variant

Module ID: MOD-FOCUS-FS07-LOW-ALT. Content version: 1.0. Review: NEEDS_EXPERT_REVIEW.

## Purpose and scenario

Practice **perform software unit testing** using an order-management application with browser, service and database layers. This locally authored review package is a scaffold for expert lesson/lab authoring, not a complete approved course.

## Teaching focus and difficulty

| Skill | Teaching focus | Difficulty | Meaning |
|---|---|---|---|
| MS-FS07 — perform software unit testing | PRIMARY | LOW | Main instructional objective, with direct practice and evidence. |
| MS-FS06 — debug software | SUPPORTING | LOW | Supporting activity, not an equivalent primary treatment. |
| MS-CORE02 — Manage source changes with version control | INCIDENTAL | LOW | Context only; no teaching or mastery credit. |

## Read and prepare

Read [the retained source-linked introduction](MOD-FS-J-QUALITY-01.md) for terminology and references. It is a reference, not a compulsory module completion. Review the supplied scenario, inputs and expected outputs with the instructor. For real use, experts must provide and approve the actual sandbox assets, worked examples and task/rubric configuration.

## Primary task

Add automated unit tests for a supplied function with meaningful assertions and guidance. Focus this variant on a reproducible defect: write a failing regression test, diagnose the cause and verify the correction.

Use a supplied worked example and step-by-step checklist. Change one input, execute the checks and explain the observed result.

## Supporting task

Reproduce a bounded defect and verify a guided fix with a regression check. The supporting activity develops debug software; review its evidence separately from the primary result.

## Incidental context

A repository snapshot is provided as context; source-control operations are not taught or assessed here. Merely using that context does not close a gap for MS-CORE02.

## Checks and evidence

Submit the primary artifact, stated assumptions, expected-versus-observed checks and one limitation. Include evidence for the supporting activity. For HIGH difficulty, add the alternative comparison, failure analysis and recovery checks; for MEDIUM, include diagnosis and correction; for LOW, retain the worked-example checklist and changed-input result. No evidence or attainment decision is claimed for incidental context.

## Readiness and assessment boundary

Skill prerequisite edges determine readiness; supporting/incidental links do not create new prerequisites. An approved external task/rubric and compatible learner evidence are required to confirm readiness or attainment. Difficulty is an expert authoring category, not a numeric score threshold, role-Level shortcut, or expected mastery increase. Completion never automatically passes any skill.
