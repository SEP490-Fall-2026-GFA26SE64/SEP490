BỘ THỬ IMPORT 20 LEARNING MODULE — TEXT + VIDEO

Upload file learning-modules-20-text-video.zip tại Expert → Modules → Import.
Không upload riêng modules.xlsx: các bài VIDEO dùng videoPath trong thư mục videos/.

Nội dung: 20 module, 40 bài học (20 TEXT + 20 VIDEO), mức FOUNDATION.
5 kỹ năng: MS-QA08, MS-QA10, MS-QA11, MS-QA13, MS-QA14 (4 module/kỹ năng).
Các kỹ năng cần thuộc organization, đang ACTIVE/APPROVED và được cấu hình học qua module.
Bộ thử được chuẩn bị cho workspace-development.

Video do bộ thử tạo: MP4 H.264, 960×540, 24 giây, 3 slide, không âm thanh.
Tất cả nội dung nằm trong ZIP, không phụ thuộc YouTube/Vimeo.
Bài TEXT có mục tiêu, ví dụ, bước thực hiện, bài tập tự luyện và đáp án tham khảo.

moduleRef chỉ ghép các dòng; mã module thật do hệ thống tạo.
Mỗi lần XÁC NHẬN import tạo 20 module NHÁP MỚI, tên bắt đầu [IMPORT20].
Chưa gửi duyệt/phát hành và chưa tự tạo Question Bank hoặc Skill Assessment.
Sau import, dùng quy trình gửi duyệt/phát hành hiện có để Employee học.
