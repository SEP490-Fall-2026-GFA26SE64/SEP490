# Senior Test automation and integration - Module 1: Design review and trade-offs

Module ID: MOD-QA-S-AUTO-01. Content version: 1.0. Review: NEEDS_EXPERT_REVIEW.

## Learn

Read [the local lesson: Making automated checks reliable](../topics/QA-AUTO.md). It includes a conceptual explanation, worked example and a self-check with an answer. Then use the linked official resources for additional detail.

## Skill focus

- **MS-QA06: develop automated software tests** — Implement repeatable automated tests with meaningful assertions.
- **MS-QA07: execute integration testing** — Test interactions and data exchange between components.
- **MS-FS07: perform software unit testing** — Verify individual units of software with repeatable automated checks.

## Study and practice sequence

1. Read the linked local explanation and work through its example.
2. Answer the self-check before looking at the answer.
3. Inspect the official learning resources below for the techniques used in this module.
4. Complete the assigned tasks below and record checks and evidence.

## Learning prerequisites

- Before MS-QA06, demonstrate MS-QA02: Specify expected test cases before automating their execution.

Prerequisites taught within this module are studied first. Cross-module prerequisites are scheduled by the pathway engine. These are pending local learning-order decisions, not claims of universal occupational dependency.

## Assigned tasks and submission evidence


In Test automation and integration, demonstrate the following senior tasks:

- MS-QA06: Design an automation approach for team maintenance; compare alternatives and verify reliability improvements.
- MS-QA07: Review cross-system integration coverage; prioritise high-impact failures and verify recovery behaviour.
- MS-FS07: Review test quality and brittle dependencies; improve fault detection and verify the revised tests.

Submit evidence:

- MS-QA06: Automation code, fixtures, assertion rationale and repeat-run results.
- MS-QA07: Interaction map, integration cases, execution results and failure evidence.
- MS-FS07: Unit tests, fixtures, execution results and assertion rationale.

## Official learning resources

- [Playwright writing tests](https://playwright.dev/docs/writing-tests)
- [Playwright retries](https://playwright.dev/docs/test-retries)

## Assessment boundary

Completion is not an attainment decision. Rubric 1.1, level-specific evidence and approved catalog dependencies are required for official assessment. This lesson has not yet received that approval.
