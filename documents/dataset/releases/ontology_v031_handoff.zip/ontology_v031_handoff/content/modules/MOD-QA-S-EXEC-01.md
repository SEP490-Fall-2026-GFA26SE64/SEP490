# Senior Test execution and defect evidence - Module 1: Design review and trade-offs

Module ID: MOD-QA-S-EXEC-01. Content version: 1.0. Review: NEEDS_EXPERT_REVIEW.

## Learn

Read [the local lesson: Keeping test evidence reproducible](../topics/QA-EXEC.md). It includes a conceptual explanation, worked example and a self-check with an answer. Then use the linked official resources for additional detail.

## Skill focus

- **MS-QA03: execute software tests** — Run specified tests and record observed results.
- **MS-QA04: report test findings** — Communicate test results and defects with supporting evidence.
- **MS-QA05: replicate customer software issues** — Reproduce a reported issue under identified conditions.

## Study and practice sequence

1. Read the linked local explanation and work through its example.
2. Answer the self-check before looking at the answer.
3. Inspect the official learning resources below for the techniques used in this module.
4. Complete the assigned tasks below and record checks and evidence.

## Assigned tasks and submission evidence


In Test execution and defect evidence, demonstrate the following senior tasks:

- MS-QA03: Review execution evidence across releases; identify unreliable results and justify follow-up testing.
- MS-QA04: Synthesize test findings for a release decision; explain residual risk and evidence limitations.
- MS-QA05: Review intermittent customer issues; compare hypotheses and define a minimal reproducible case or explicit evidence limits.

Submit evidence:

- MS-QA03: Execution log, environment details, expected/actual results and failure evidence.
- MS-QA04: Defect reports, supporting evidence, test summary and decision notes.
- MS-QA05: Reproduction steps, environment comparison, logs and controlled reruns.

## Official learning resources

- [Playwright writing tests](https://playwright.dev/docs/writing-tests)
- [ISTQB CTFL 4.0.1 syllabus](https://istqb.org/?download_id=3345&sdm_process_download=1)

## Assessment boundary

Completion is not an attainment decision. Rubric 1.1, level-specific evidence and approved catalog dependencies are required for official assessment. This lesson has not yet received that approval.
